<?php

const ORIG_IMG_PATH= 'img/orig_img';
const SMALL_IMG_PATH = 'img/small_img';

require_once 'Twig/Autoloader.php';
Twig_Autoloader::register();

try {

  $load = new Twig_Loader_Filesystem('templates');

  $twig = new Twig_Environment($load);
  
  $temp = $twig->loadTemplate('img.tmpl');
  
  $img = $_GET['img'];

  echo $temp->render(array(
            'title' => 'All images',
            'path_img' => ORIG_IMG_PATH,
            'img' => $img
            ));
  
} catch (Exception $e) {
  die ('ERROR: ' . $e->getMessage());
}
?>
