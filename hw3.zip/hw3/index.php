<?php

const ORIG_IMG_PATH= 'img/orig_img';
const SMALL_IMG_PATH = 'img/small_img';

require_once 'Twig/Autoloader.php';
Twig_Autoloader::register();

try {
  $load = new Twig_Loader_Filesystem('templates');
  
  $twig = new Twig_Environment($load);
  
  $temp = $twig->loadTemplate('index.tmpl');
  
  $imgs_in_dir = array_slice(scandir(ORIG_IMG_PATH), 1);

  echo $temp->render(array(
            'title' => 'All images',
            'path_img_small' => SMALL_IMG_PATH,
            'imgs' => $imgs_in_dir
            ));
  
} catch (Exception $e) {
  die ('ERROR: ' . $e->getMessage());
}
?>
